$(document).ready(function () {
    $("img")
    .mouseover(function () { 
        $(this).attr("src","ga.jpg")
        .animate({height: '+=200px',width: '+=200px'})
    })
    .mouseout(function () { 
        $(this).attr("src", "Hamburger.jpg")
        .animate({height: '-=200px',width: '-=200px'})
    });
});