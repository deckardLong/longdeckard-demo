function drawChart() {
    var xValues = document.getElementById("txtData").value.split(",");
    var yValues = [];
    var barColors = [];
    for (var i = 0; i < xValues.length; i++) {
        yValues[i] = Number(xValues[i]);
        barColors[i] = "rgb(" +
            Math.floor(Math.random() * 256) + "," +
            Math.floor(Math.random() * 256) + "," +
            Math.floor(Math.random() * 256) + ")";
    }
    new Chart("canvas", {
        type: "pie",
        data: {
            labels: xValues, 
            datasets: [{
                backgroundColor: barColors,
                data: yValues
            }]
        },
        options: { 
            plugins: {
                title: {
                    display: true,
                    text: "Pie Chart"
                }
            }
        }
    });
}