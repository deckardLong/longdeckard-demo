$(document).ready(function () {
    $("#changeColor").click(function () { 
        $("tr:odd").addClass("newBg");
    });
    $("#resetColor").click(function () { 
        $("tr:odd").removeClass("newBg");
    });
});