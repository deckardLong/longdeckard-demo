$(document).ready(function () {
    $("#calDay").click(function (e) { 
        e.preventDefault();
        var t1 = $("#fromDay").val();
        var t2 = $("#toDay").val();
        d1 = new Date(t1);
        d2 = new Date(t2);
        var result = (d2.getTime() - d1.getTime())/(24*3600*1000);
        $("#result").text(result);
    });
});