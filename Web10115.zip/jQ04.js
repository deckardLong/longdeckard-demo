$(document).ready(function () {
    $("div div").click(function (e) { 
        e.preventDefault();
        var color = $(this).css("background-color");
        var name;
        switch (color) {
            case "rgb(0, 0, 255)": name = "Xanh dÆ°Æ¡ng"; break;
            case "rgb(255, 0, 0)": name = "Ä‘á»"; break;
            case "rgb(255, 0, 255)": name = "tÃ­m"; break;
            case "rgb(0, 255, 0)": name = "xanh lÃ¡"; break;
        }
        $("#resultText").html("Màu bạn chọn là  " + name + ": " + color);
        $("#resultText").css({'color': color, 'font-weight': 'bold'});
        $("#result").css("background-color",color);
    });
});