function draw() {
    var canvas = document.getElementById("canvas");
    var c = canvas.getContext("2d");
    c.fillStyle = "#00ffff";
    c.fillRect(0, 0, 400, 400);
  
    c.beginPath();
  
    c.arc(200, 200, 199, 0, 2 * Math.PI);
    var grd = c.createLinearGradient(0, 0, 0, canvas.height);
    grd.addColorStop(0, "red");
    grd.addColorStop(0.25, "green");
    grd.addColorStop(0.5, "yellow");
    grd.addColorStop(0.75, "green");
    grd.addColorStop(1, "red");
  
    c.fillStyle = grd;
    c.fill();
    c.strokeStyle = "blue";
    c.stroke();
  
    c.beginPath();
    c.moveTo(200, 0);
    c.lineTo(400, 200);
    c.lineTo(200, 400);
    c.lineTo(0, 200);
    c.lineTo(200, 0);
  
    c.fillStyle = "yellow";
    c.fill();
    c.strokeStyle = "#ff00ff";
    c.lineWidth = 1;
    c.stroke();
    c.font = "80px Arial";
    c.lineWidth = 3;
    c.strkoStyle = "blue";
    c.fillStyle = "cyan";
    c.strokeText("HTML5", canvas.width / 6, canvas.height / 2 + 20);
  }