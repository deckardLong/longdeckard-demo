$( function() {
    $( "#ball" ).draggable();
  } );

$(document).keydown(function(e) {
    var speed = 30;
    switch (e.which) {
    case 37:
        var move = '-='+speed+'px';
        $('#ball').stop().animate({
            left: move
        },10);
        break;
    case 38:
        var move = '-='+speed+'px';
        $('#ball').stop().animate({
            top: move
        },10);
        break;
    case 39:
        var move = '+='+speed+'px';
        $('#ball').stop().animate({
            left: move
        },10);
        break;
    case 40:
        var move = '+='+speed+'px';
        $('#ball').stop().animate({
            top: move
        },10);
        break;
    }
})