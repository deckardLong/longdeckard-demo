
function insert() {
    var name = $("#textInput").val();
    if(name.trim() != "") {
        $("ul").append("<li>"+name+"</li>");
    }
    $("#textInput").val("");
}

$(document).ready(function(){
    $("button").click(function(){
        insert();
    })
    $("#textInput").change(function(){ 
        insert();
    });
})